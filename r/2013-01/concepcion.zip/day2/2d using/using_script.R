# load(file)
# save(ls(), file)
# save(bigobj, file)
# source(file)
# dump(obj, file)

find("function")
search()
# library()
# library(pkg)
# ls("package:pkg")
# install.packages("pkg")
# update.packages()

# Args(fun)
# env()
# is.what(obj)
# ll()
# ll(obj)

# install.packages("pkg")

# history()
# history(Inf)

# source("script.R")

args(log)
apropos("log")
# help(log, help_type="html")
# help(log)
# ?log
# ?"["
# help(package="pkg")
# help.search("keyword")
# ??keyword

lm
logLik.lm
getAnywhere(logLik.lm)

# RSiteSearch("keyword")
