## This function calculates the
## cumulative sum of a vector
cumulative <- function(vec)
{
  n <- length(vec)
  output <- numeric(n)

  output[1] <- vec[1]

  if(n >= 2)
  {
    for(i in 2:n)
    {
      output[i] <- output[i-1] + vec[i]
    }
  }

  return(output)
}
