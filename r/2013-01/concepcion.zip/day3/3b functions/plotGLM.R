plotGLM <- function(mydata)
{
  ## Fit model
  mimodelo <- glm(Maturity~Age, data=mydata,
                  family=binomial)

  ## Calculate vectors
  prop <- aggregate(Maturity~Age, data=mydata,
                    FUN=mean)
  myages <- seq(min(mydata$Age),
                max(mydata$Age), length=100)
  myline <- predict(mimodelo,
                    data.frame(Age=myages),
                    type="response")
  res <- residuals(mimodelo, type="response")
  fit <- fitted(mimodelo)

  ## Start plotting
  par(mfrow=c(1,3))
  plot(prop)
  lines(myages, myline)
  plot(fit, res)
  abline(h=0)
  hist(res)

}
