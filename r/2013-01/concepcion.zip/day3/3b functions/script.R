hello <- function()
{
  return("Hello world")
}



hello2 <- function()
{
  output <- "Hello again"
  return(output)
}



twice <- function(x)
{
  y <- 2 * x
  return(y)
}



multiply <- function(x, y)
{
  output <- x * y
  return(output)
}



plotGLM <- function(x, y)
{
  ## Fit model
  mimodelo <- glm(y~x, family=binomial)
  ## Calculate vectors
  prop <- aggregate(y~x, FUN=mean)
  myX <- seq(min(x), max(x), length=100)
  myFit <- predict(mimodelo, data.frame(x=myX), type="response")
  res <- residuals(mimodelo, type="response")
  fit <- fitted(mimodelo)
  ## Start plotting
  par(mfrow=c(1,3))
  plot(prop)
  lines(myX, myFit)
  plot(fit, res)
  abline(h=0)
  hist(res)
}
