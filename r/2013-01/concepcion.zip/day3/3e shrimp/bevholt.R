## Fit a Beverton-Holt model to stock-recruitment data
## 'par' is a named vector with elements "a", "b", and "sigma"
## 'data' is a data frame with columns "S" and "R"
## The function returns the negative log likelihood
bevholt <- function(par, data)
{
  a <- par[["a"]]
  b <- par[["b"]]
  sigma <- par[["sigma"]]

  Rfit <- (a*data$S) / (b+data$S)
  res <- data$R - Rfit

  n <- nrow(data)
  RSS <- sum(res^2)

  ## plot(data[2:1], xlim=c(0,35), ylim=c(0,6))
  ## points(data$S, Rfit, pch="-", col="red", cex=4)

  neglogL <- 0.5*n*log(2*pi) + n*log(sigma) + RSS / (2*sigma^2)

  return(neglogL)
}
