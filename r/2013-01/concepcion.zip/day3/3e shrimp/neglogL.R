## Two ways to evaluate neglogL, using Bev-Holt as example
a <- 1
b <- 0.5
sigma <- 1

Rfit <- shrimp$S / (a + b*shrimp$S)
res <- shrimp$R - Rfit

n <- nrow(shrimp)
RSS <- sum(res^2)


-sum(dnorm(shrimp$R, m=Rfit, s=sigma, log=T))
