hess <- function(H, cor=FALSE)
########################################################################################################################
###                                                                                                                    #
### Function: hess                                                                                                     #
###                                                                                                                    #
### Purpose:  Evaluate standard errors or correlation matrix from Hessian matrix                                       #
###                                                                                                                    #
### Args:     H is a Hessian matrix                                                                                    #
###           cor is whether to return correlation matrix instead of standard errors                                   #
###                                                                                                                    #
### Notes:    The covariance matrix can be useful for applying the delta method                                        #
###                                                                                                                    #
### Returns:  Vector of standard errors, or if cor=TRUE a correlation matrix                                           #
###                                                                                                                    #
### History:  17 Jan 2013  Arni Magnusson released                                                                     #
###                                                                                                                    #
########################################################################################################################
{
  V <- solve(H)                      # covariance matrix
  sigma <- sqrt(diag(V))             # std errors
  if(cor)
    output <- V / (sigma %o% sigma)  # correlation matrix
  else
    output <- sigma

  return(output)
}
