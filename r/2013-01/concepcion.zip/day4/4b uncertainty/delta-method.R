## Demonstration of the delta method, see Magnusson (2002) and 'airquality'

mimodelo <- lm(Ozone~Month+I(Month^2), data=airquality)

VarB1 <- 22.145043^2
VarB2 <- 1.580393^2
CovB1B2 <- -34.87164  # from vcov(mimodelo)
B1 <- 113.290914
B2 <- -7.850927
Mopt <- -1/2 * B1/B2

# Var(Mopt)
Mopt^2 * (VarB1/B1^2 + VarB2/B2^2 - 2*CovB1B2/(B1*B2))

# SE(Mopt)
sqrt(Mopt^2 * (VarB1/B1^2 + VarB2/B2^2 - 2*CovB1B2/(B1*B2)))
