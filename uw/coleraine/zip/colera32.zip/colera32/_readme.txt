Coleraine 3.2 release notes

Several versions of Coleraine have gone by the name "version 2.0", which has
been the source of some confusion. Version 3.2 combines bug fixes and features
from earlier versions, and is fully backward-compatible with the following
caveat.

*Important*

The number that served historically as the Brody rho parameter now specifies
whether sigmaL@A increases linearly with age or length. This value is located
after t0 in the input sheet and must be either 1 or 2.



Coleraine 3.2 was compiled 1 March 2003 by Billy Ernst. Its main features are:

- free of bugs that existed in some earlier versions (lost plus group,
  sex-specific selectivity offset didn't work)

- selectivity parameters can be estimated for some gears and fixed for others

- likelihood flags:  0 = not used, not reported
                    -d = not used, but reported as distribution d

- user specifies whether sigmaL@A increases linearly with age or length

- comes with a new Excel file bundle, with improved input sheet labels
