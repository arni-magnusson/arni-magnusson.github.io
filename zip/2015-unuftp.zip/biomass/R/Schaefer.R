icod_short <- read.table("../data/icod_short.dat", header=TRUE)
best <- c(logr=-0.481, logK=7.478, logBinit=7.053, logq=-0.833)

Schaefer <- function(par, data, verbose=FALSE)
{
  r <- exp(par["logr"])
  K <- exp(par["logK"])
  Binit <- exp(par["logBinit"])
  q <- exp(par["logq"])
  year <- data$Year
  C <- data$Catch
  I <- data$Index
  n <- length(year)
  B <- numeric(n)
  B[1] <- Binit
  for(i in 1:(n-1))
  {
    B[i+1] <- max(B[i] + r*B[i]*(1-B[i]/K) - C[i], 1)
  }
  Ifit <- q*B

  res <- log(I) - log(Ifit)
  RSS <- sum(res^2)
  sigma <- sqrt(RSS/n)
  neglogL <- -sum(dnorm(log(I), log(Ifit), sigma, log=TRUE))

  if(verbose)
    output <- list(B=B, Ifit=Ifit, sigma=sigma, res=res)
  else
    output <- neglogL

  return(output)
}


Schaefer(par=best, data=icod_short)
init <- c(logr=-0.4, logK=7.5, logBinit=7, logq=-1.5)
optim(init, Schaefer, data=icod_short)
