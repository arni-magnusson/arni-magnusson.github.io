prof <- data.frame(logr=seq(-3, 0, 0.01), neglogL=0)

for(i in 1:nrow(prof))
{
  ctl <- read.table("icod_short.ctl")
  ctl[1,1] <- -1
  ctl[1,4] <- prof$logr[i]
  write.table(ctl, "icod_short.ctl", row.names=FALSE, col.names=FALSE)
  system("pella -ind icod_short.dat")
  prof$neglogL[i] <- scan("pella.par", what="", nlines=1)[11]
}
