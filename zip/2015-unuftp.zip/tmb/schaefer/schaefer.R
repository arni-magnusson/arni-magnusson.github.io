shrimp <- read.table("schaefer.dat", skip=4, col.names=c("t","C","I"))

parameters <- list()
parameters$logr <- -0.27
parameters$logk <- 9.8
parameters$loga <- -0.68
parameters$logq <- -9.5
parameters$logsigma <- -2.2

require(TMB)
compile("schaefer.cpp")
dyn.load(dynlib("schaefer"))
model <- MakeADFun(shrimp, parameters)
fit <- nlminb(model$par, model$fn, model$gr)

H <- model$he(fit$par)
rep <- sdreport(model, hessian=H)
print(summary(rep))
shrimp$B <- model$report()$B
shrimp$Ihat <- model$report()$Ihat
print(model$report()$f)
