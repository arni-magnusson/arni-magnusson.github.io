#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  DATA_VECTOR(C);
  DATA_VECTOR(I);
  int n = I.size();

  PARAMETER(logr);
  PARAMETER(logk);
  PARAMETER(loga);
  PARAMETER(logq);
  PARAMETER(logsigma);
  Type r = exp(logr);
  Type k = exp(logk);
  Type a = exp(loga);
  Type q = exp(logq);
  Type sigma = exp(logsigma);
  vector<Type> B(n);
  vector<Type> logB(n);
  Type logBnext;
  Type logMSY;
  vector<Type> Ihat(n);
  Type f;

  B(0) = a * k;
  for(int t=0; t<(n-1); t++)
  {
    B(t+1) = abs(B(t) + r*B(t)*(1-B(t)/k) - C(t));
  }
  Ihat = q * B;
  f = -sum(dnorm(log(I), log(Ihat), sigma, true));

  logB = log(B);
  logBnext = log(abs(B(n-1) + r*B(n-1)*(1-B(n-1)/k) - C(n-1)));
  logMSY = log(0.25 * r * k);

  // Uncertainty
  ADREPORT(logB);
  ADREPORT(logBnext);
  ADREPORT(logMSY);
  // Plot
  REPORT(B);
  REPORT(logBnext);
  REPORT(exp(logBnext)*0.5*r);
  REPORT(Ihat);
  REPORT(f);

  return f;
}
