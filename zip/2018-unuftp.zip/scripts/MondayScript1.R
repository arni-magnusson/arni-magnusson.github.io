library(RODBC)

con <- odbcConnectAccess2007("c:/database/onetable.accdb")

sqlTables(con)

catch <- sqlQuery(con, "SELECT * FROM catch WHERE tonnes<1")

boxplot(catch$TONNES)

hist(catch$TONNES)

#############################################################

catch <- read.csv("c:/database/data/catch.csv")
