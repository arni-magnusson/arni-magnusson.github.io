library(RODBC)
con <- odbcConnectAccess2007("c:/database/Logbooks.accdb")
sqlTables(con)

sqlQuery(con, "

SELECT tonnes, crew
  FROM catch, events
 WHERE catch.event=events.event
   AND tonnes=29

")
