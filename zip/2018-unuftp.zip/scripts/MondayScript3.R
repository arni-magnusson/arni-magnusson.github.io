library(RODBC)
con <- odbcConnectAccess2007("c:/database/Logbooks.accdb")
sqlTables(con)

sqlQuery(con, "

   SELECT ship, sum(tonnes) AS total
     FROM events e, catch c
    WHERE e.event=c.event
 GROUP BY ship

")

