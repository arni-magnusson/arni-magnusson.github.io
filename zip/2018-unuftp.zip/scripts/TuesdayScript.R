library(RODBC)
con <- odbcConnectAccess2007("c:/database/Logbooks.accdb")
sqlTables(con)

sqlQuery(con, "

SELECT
  g.english AS gearname,
  sum(tonnes) AS total
FROM
  catch c,
  events e,
  gears g,
  species s
WHERE
  c.species = s.species AND
  c.event = e.event AND
  e.gear = g.gear AND
  s.english = 'Saithe'
GROUP BY
  g.english

")
