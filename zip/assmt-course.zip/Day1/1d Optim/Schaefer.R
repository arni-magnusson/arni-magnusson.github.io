hake <- read.csv("1b Hake/hake.csv")
best <- c(logr=-1.01, logK=7.974, logq=-7.946, logBinit=8.518)

Schaefer <- function(par, data, verbose=FALSE)
{
  r <- exp(par["logr"])
  K <- exp(par["logK"])
  q <- exp(par["logq"])
  Binit <- exp(par["logBinit"])
  year <- data$t
  C <- data$C
  I <- data$I
  n <- length(year)
  B <- numeric(n)
  B[1] <- Binit
  for(i in 1:(n-1))
  {
    B[i+1] <- max(B[i] + r*B[i]*(1-B[i]/K) - C[i], 1)
  }
  Ifit <- q*B

  res <- log(I) - log(Ifit)
  RSS <- sum(res^2)
  resbar <- mean(res)
  sigma <- sqrt(sum((res-resbar)^2)/n)
  neglogL <- -sum(dnorm(log(I), log(Ifit), sigma, log=TRUE))

  if(verbose)
    output <- list(B=B, Ifit=Ifit, res=res)
  else
    output <- neglogL

  return(output)
}


Schaefer(par=best, data=hake)
init <- c(logr=-1, logK=8, logq=-8, logBinit=8.5)
optim(init, Schaefer, data=hake)


